package dev.maree.datafromrefmar.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.log4j.Logger;



import dev.maree.prereq.constantes.Constantes;
import dev.maree.prereq.logger.MyLogger;
import dev.maree.prereq.structuredonnee.ListDataType;
import dev.maree.prereq.structuredonnee.ListStation;


public class DownloadFromRefMar 
{
	public DownloadFromRefMar() {}
	
	// http://refmar.shom.fr/onivmer/download?id=pfages&pass=Fripouille.2010&idstation=103&idsource=2&datedeb=2011-12-05&datefin=2011-12-06
	final String _user = "pfages";
	final String _passwd = "Fripouille.2010";

	final String _RefMarURL = "http://refmar.shom.fr/onivmer/download?id=" + _user + "&pass=" +_passwd;
	final String _Station = "&idstation=";
	final String _TypeData = "&idsource=";
	final String _deb = "&datedeb=";
	final String _fin =	"&datefin=";

	public File _output = null;
	Logger _log = null;
	
	GregorianCalendar _Start = null;
	GregorianCalendar _End = null;


	public void Go() 
	{
		_log =  MyLogger.getLogger();
		
		//--------------------
		// le format des dates pour debug
		//--------------------

		ListStation station = ListStation.SaintMalo;
		ListDataType typedonees = ListDataType.DiffereeHoraire;
		_Start = new GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.ROOT); 
		_Start.set(Calendar.YEAR, 2008);
		_Start.set(Calendar.MONTH, Calendar.JANUARY);
		_Start.set(Calendar.DAY_OF_MONTH, 01);
		
		_End = new GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.ROOT); 
		_End.set(Calendar.YEAR, 2013);
		_End.set(Calendar.MONTH, Calendar.JANUARY);
		_End.set(Calendar.DAY_OF_MONTH, 01);

		//--------------------
		// le fichier de donnees
		//--------------------
		File outDir = new File (Constantes.RepDonneeDownload);
		if (!outDir.exists())
			outDir.mkdirs();

		String outName = station._nom + "_" + typedonees._nom + "_" +  Constantes._sdf4file.format(_Start.getTime()) + "_" + Constantes._sdf4file.format(_End.getTime()) + ".txt";
		_log.debug("File name :" + outName);

		File out = new File (outDir, outName);
		try
		{
			FileWriter fw = new FileWriter(out, false);



			String getURL = _RefMarURL + _Station + Integer.toString(station._id) + _TypeData + Integer.toString(typedonees._id) + _deb + Constantes._sdf4file.format(_Start.getTime()) + _fin + Constantes._sdf4file.format(_End.getTime());
			_log.debug("URL :" + getURL);
			URL url = new URL(getURL);		     

			// Envoie
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);

			// retour
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = rd.readLine()) != null) 
			{
				fw.append(line + System.getProperty("line.separator"));
			}
			rd.close();
			fw.close();
		} 
		catch (Exception e) 
		{
			_log.fatal(e.getMessage());
			e.printStackTrace();
		}
	}
}
