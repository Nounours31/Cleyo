package main;


import org.apache.log4j.Logger;

import dev.maree.datafromrefmar.model.DownloadFromRefMar;
import dev.maree.prereq.constantes.Constantes;
import dev.maree.prereq.logger.MyLogger;

/**
 * @author pfs
 * @version 1.0
 */
public class Start 
{
	static Logger _log = null;
	
	/**
	 * lancement de la phase 1 download des donnees
	 * @param args pas d'util
	*/
	public static void main(String[] args)  
	{
		//--------------------
		// le logger
		//--------------------
		_log =  MyLogger.getLogger();
		DownloadFromRefMar xx = new DownloadFromRefMar();
		
		xx.Go();
	}
}
