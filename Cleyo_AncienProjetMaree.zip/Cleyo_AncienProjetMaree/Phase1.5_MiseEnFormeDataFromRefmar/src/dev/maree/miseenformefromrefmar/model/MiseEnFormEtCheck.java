package dev.maree.miseenformefromrefmar.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import dev.maree.prereq.constantes.Constantes;
import dev.maree.prereq.error.MyError;
import dev.maree.prereq.exception.MareeException;
import dev.maree.prereq.logger.MyLogger;
import dev.maree.prereq.structuredonnee.DateHauteur;

public class MiseEnFormEtCheck 
{
	Logger _log = null;

	public MiseEnFormEtCheck() {}

	public MyError go()
	{
		//------------------------------------------------------------------------------------------------
		//-- le loggeur
		//------------------------------------------------------------------------------------------------
		MyError err = MyError.sOK;
		_log =  MyLogger.getLogger();

		//------------------------------------------------------------------------------------------------
		//-- Repertoire d'output des fichiers au format de calcul des coeff
		//------------------------------------------------------------------------------------------------
		File outDir = new File (Constantes.RepDonneeCheck);
		if (!outDir.exists())			
			outDir.mkdirs();

		//------------------------------------------------------------------------------------------------
		//-- le fichier de donnees du SHOM via Refmar
		//------------------------------------------------------------------------------------------------
		File inDir = new File (Constantes.RepDonneeDownloadCorrigee);
		if (!inDir.exists())
			return new MyError(1, "Pas de download disponible");


		//------------------------------------------------------------------------------------------------
		//-- Choix user d'un fichier IN
		//------------------------------------------------------------------------------------------------
		String[] dowloadfiles = inDir.list();
		short NbDownloadedFiles = 0;
		for (String i : dowloadfiles)
			System.out.println("Indice: " + NbDownloadedFiles++ + " Nom: " + i);

		int choix = -1;
		boolean test = false;
		do
		{
			System.out.print("Votre choix ? ");

			int car = 0;
			String inputString = "";

			try
			{
				do
				{
					car = System.in.read();
					test = ((car > -1) && (car != 10) && (car != 13) );  // 10 = \n   13 = \r
					if (test)
						inputString += String.valueOf(Character.toChars(car));
				} while (test);
			}
			catch (Exception e)
			{
				System.out.println("Choix invalide");
				choix = -2;
			}


			if (choix != -2)
			{
				try
				{
					choix = Integer.parseInt(inputString);
				}
				catch (Exception e)
				{
					System.out.println("Choix n'est pas un integer");
				}
			}
			
			test = (choix > -1) && (choix < NbDownloadedFiles);
			if (!test)
				System.out.println("Choix trop petit ou superieur au nb fichier, a refaire");
		}
		while (!test);

		
		
		//------------------------------------------------------------------------------------------------
		//-- choix des fichier et creation si necessaire
		//------------------------------------------------------------------------------------------------
		File infile = new File (inDir, dowloadfiles[choix]);
		File outfile = new File (outDir, dowloadfiles[choix] + ".check");
		
		if (outfile.exists())
			outfile.delete();
		
		
		
		
		//------------------------------------------------------------------------------------------------
		//-- scan, check et copie si OK
		//------------------------------------------------------------------------------------------------
		FileReader fr = null;
		FileWriter fw = null;
		
		BufferedReader br = null;
		BufferedWriter bw = null;
		try
		{
			fr = new FileReader(infile);
			fw = new FileWriter(outfile);
			br = new BufferedReader(fr);
			bw = new BufferedWriter(fw);

			_log.debug("Ouverture du fichier de data: " + infile.toString());
			_log.debug("Clean vers de fichier : " + outfile.toString());
									
			boolean isFirstRecord = true;
			DateHauteur DateHauteurDeb = new DateHauteur();
			DateHauteur DateHauteurprevious = new DateHauteur();
			DateHauteur DateHauteurcurrent = new DateHauteur();
			
			try
			{
				String line;
				while ((line = br.readLine()) != null) 
				{
					_log.debug("Line : " + line);
					
					//---------------------------------------
					//- check si ligne avec des donn�es
					//---------------------------------------
					if (this.isdataline (line))
					{
						//---------------------------------------
						//- check si ce sont des donnes au bon format
						//---------------------------------------
						if (this.isvaliddata (line))
						{
							DateHauteur xtoto = new DateHauteur();
							this.getvaliddata (line, xtoto);
							
							//---------------------------------------
							//- check si le couple Hauteur/Horaire est valide
							//---------------------------------------
							if (xtoto.isValid())
							{
								if (isFirstRecord)
								{
									_log.debug("FirstRecord");
									DateHauteurDeb = xtoto;
									DateHauteurprevious = xtoto;
									isFirstRecord = false;
								}
								else
								{
									DateHauteurcurrent = xtoto;
									_log.debug ("Interval horaire : " + DateHauteur.MilliSecond2Hour(DateHauteur.interval(DateHauteurcurrent, DateHauteurprevious)));
									_log.debug("DateHauteurcurrent : " +DateHauteurcurrent.toString());
									_log.debug("DateHauteurprevious : " +DateHauteurprevious.toString());
									
									//---------------------------------------
									//- check si les releve sont consecutif (delta horaire = 1:00) 
									//---------------------------------------
									if ((Math.abs(DateHauteur.MilliSecond2Hour(DateHauteur.interval(DateHauteurcurrent, DateHauteurprevious))) - 1.0) > 0.001)
									{
										String msg = "Interval de temps entre deux sondes invalide : <"+DateHauteur.MilliSecond2Hour(DateHauteur.interval(DateHauteurcurrent, DateHauteurprevious))+">";
										msg += "\nJour d'avant : " + DateHauteurprevious.toString();
										msg += "\nJour courrant : " + DateHauteurcurrent.toString();
										throw new MareeException(msg);
									}
									DateHauteurprevious = xtoto;
								}
								
								//---------------------------------------
								//- tous les checks sont passes, on valide l'enreg
								//---------------------------------------
								_log.debug(System.getProperty("line.separator") + "lu    : [" + line + "]" + System.getProperty("line.separator") + "Ecrit : [" + Constantes._sdf.format(xtoto.get_horaireMaree().getTime()) + ";" + xtoto.get_hauteurEau() +"]");
								bw.append(Constantes._sdf.format(xtoto.get_horaireMaree().getTime()) + ";" + xtoto.get_hauteurEau() + System.getProperty("line.separator"));							
							}
						}
						else
						{
							throw new MareeException("Line match KO");
						}
					}
				}
			}
			catch (Exception e) 
			{
				_log.fatal(e.getMessage());
				e.printStackTrace();
			}
			
			br.close();
			bw.close();			
		} 
		catch (Exception e) 
		{
			_log.fatal(e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			br = null;
			bw = null;
		}
	

		return err;
	}

	
	
	
	
	
	
	//----------------------------------------------------------------------------------------
	//- check si ce sont des donnes au bon format : dd/mm/yyyy hh:mm:ss;hauteur;type_source
	//----------------------------------------------------------------------------------------
	private boolean isvaliddata(String line) 
	{
		try
		{
			// 01/01/2008 00:00:00;9.100;4
			Pattern pat = Pattern.compile("^\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}:\\d{2};[0-9]*\\.?[0-9]*;\\d");
			Matcher match = pat.matcher(line);
			boolean xtest = match.find();
			return xtest;
		}
		catch (Exception e)
		{
			_log.debug (e.getMessage());
		}
		return false;
	}
	

	
	
	//----------------------------------------------------------------------------------------
	//- Si OK recup de hauteur, horaire
	//----------------------------------------------------------------------------------------
	private boolean getvaliddata(String line, DateHauteur response) // date, haute 
	{
		try
		{
			// 01/01/2008 00:00:00;9.100;4
			Pattern pat = Pattern.compile("^\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}:\\d{2};[0-9]*\\.?[0-9]*;\\d");
			Matcher match = pat.matcher(line);
			boolean xtest = match.find();
			_log.debug("isvaliddata : " + xtest);

			if (xtest)
			{
				//----------------------------------------------------
				// parse de la date
				//----------------------------------------------------
				Pattern patdate = Pattern.compile("\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}:\\d{2}");
				Matcher matchdate = patdate.matcher(line);
				xtest = matchdate.find();
				_log.debug("isvaliddata  date match : " + xtest);
				
				if (xtest)
				{
					String date = matchdate.group(0);
					GregorianCalendar xdate = new GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.FRANCE);
					xdate.setTime(Constantes._sdf.parse(date));				
					response.set_horaireMaree(xdate);
					line = matchdate.replaceAll("xxxxxx");
				}
				else
				{
					throw new MareeException("Date match KO");
				}

				
				//----------------------------------------------------
				// parse de la hauteur
				//----------------------------------------------------
				Pattern patFloat = Pattern.compile("[0-9]*\\.[0-9]*");
				Matcher matchFloat = patFloat.matcher(line);
				xtest = matchFloat.find();
				_log.debug("isvaliddata  Float match : " + xtest);
				
				if (xtest)
				{
					float hauteur = Float.parseFloat(matchFloat.group(0));
					response.set_hauteurEau(hauteur);
				}
				else
				{
					throw new MareeException("Hauteur match KO");
				}
			}
			else
			{
				throw new MareeException("Line match KO");
			}
			return true;
		}
		catch (Exception e)
		{
			_log.debug (e.getMessage());
		}
		return false;
	}

	

	//----------------------------------------------------------------------------------------
	//- Est ce des donnees
	//----------------------------------------------------------------------------------------
	private boolean isdataline(String line) 
	{
		if (line.startsWith("# "))
			return false;

		if (line.startsWith("Date;Valeur;Source"))
			return false;

		_log.debug("isdataline : YES");
		return true;
	}
}
