package main;

import java.util.Calendar;
import java.util.TimeZone;

import dev.maree.miseenformefromrefmar.model.MiseEnFormEtCheck;
import dev.maree.prereq.constantes.Constantes;

public class Start {
	
	public static void main(String[] args) 
	{
		TimeZone utc = TimeZone.getTimeZone("UTC");
        TimeZone.setDefault(utc);

		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(utc);
		
        Constantes._sdf.setTimeZone(utc);
        Constantes._sdf4file.setTimeZone(utc);
		
		MiseEnFormEtCheck xx = new MiseEnFormEtCheck();
		xx.go();
	}

}
