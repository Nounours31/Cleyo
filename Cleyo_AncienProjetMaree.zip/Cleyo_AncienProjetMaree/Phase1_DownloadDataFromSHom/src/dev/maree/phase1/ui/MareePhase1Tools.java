package dev.maree.phase1.ui;



public class MareePhase1Tools 
{
	class ListPortConnusItem 
	{
		String _Nom = null;
		String _Zone = null;
		String _Opt = null;
		
		public ListPortConnusItem (String Nom, String Zone, String Opt)
		{
			_Nom = Nom;
			_Zone = Zone;
			_Opt = Opt;
		}
	}
	
	
	public ListPortConnusItem[] ListPortConnus =
	{
		new ListPortConnusItem ("BREST", "11", "12"),
		new ListPortConnusItem ("SAINT-QUAY-PORTRIEUX", "11", "12")
	};
	
	public String FindInfoFromListPortConnus (String Nom, String Info)
	{
		for (ListPortConnusItem x : ListPortConnus)
		{
			if (x._Nom.equals(Nom))
			{
				if (Info.equals("Zone"))
					return x._Zone;
				return x._Opt;
			}
		}
		return null;
	}
}
