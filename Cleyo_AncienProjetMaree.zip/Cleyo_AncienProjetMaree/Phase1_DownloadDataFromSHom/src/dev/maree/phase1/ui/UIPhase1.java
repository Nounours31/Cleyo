package dev.maree.phase1.ui;

import java.awt.Cursor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JProgressBar;
import javax.swing.ProgressMonitor;
import javax.swing.SwingWorker;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuKeyListener;

import dev.maree.phase1.model.InfoPortTools;
import dev.maree.phase1.model.Proceed;
import dev.maree.phase1.model.StatusManager;
import dev.maree.phase1.model.InfoPortTools.port;




/**
 * Classe gerant l'UI de la phase 1: recherche des info via un dowwnload du site du SHOM
 * @author pfs
 * @version 1.0
 */
public class UIPhase1 extends UIFromNetBean implements ActionListener, PropertyChangeListener, FocusListener, MenuKeyListener
{
	
	public File _DirPathToResult = null;
	
	/**
	 * Classe de gestion de la progressbar
	 * @author pfs
	 * @version 1.0
	 */
    class Task extends SwingWorker<Void, Void> 
    {
        @Override
        public Void doInBackground() 
        {
            int progress = 0;
            setProgress(0);

            while (progress < 100) 
            {
                try 
                {
                    Thread.sleep(1000);
                } 
                catch (InterruptedException ignore) 
                {}
                progress = StatusManager.getStatus();
                setProgress(progress);
            }
            return null;
        }

        @Override
        public void done() 
        {
            Toolkit.getDefaultToolkit().beep();
            jButton2.setEnabled(true);
            setCursor(null); //turn off the wait cursor
        }
    }
    
	
	/**
	 * voir http://docs.oracle.com/javase/6/docs/technotes/guides/swing/
	 * Contructeur de la classe 
	 */
    public Task task = null;
    public ProgressMonitor progressMonitor;
    
	public UIPhase1() 
	{ 
		super();
		
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });        
        
	}


    /**
     * selection du boutton de choix du repertoire de download
     * @param evt 
     */
    public void jButton1ActionPerformed(java.awt.event.ActionEvent evt) 
    {
        System.out.println("Choix du repertoire de download");
        
        jFileChooser1.setCurrentDirectory(new File("E:\\WS\\eclipse\\persoMaree\\CalculDeMaree\\Resultats"));
        jFileChooser1.setDialogTitle("Choix du repertoire de download");
        jFileChooser1.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnVal = jFileChooser1.showOpenDialog(this);
        
        if (returnVal== JFileChooser.APPROVE_OPTION) 
        {
            try 
            {
            	_DirPathToResult = jFileChooser1.getSelectedFile();                
                jTextField1.setText (_DirPathToResult.getAbsolutePath());
            }
             catch (Exception e) 
             {
                 System.out.println(e);
             }

        }

        else System.out.println("there is some error");
        jButton2.setEnabled(true);
    } 
    
    

    /**
     * Go download
     * @param evt 
     */
    public void jButton2ActionPerformed(java.awt.event.ActionEvent evt) 
    {
        System.out.println("Lancement du download");
        jButton2.setEnabled(false);
        
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        progressMonitor = new ProgressMonitor(this, "Running a Long Task", "", 0, 100);
        progressMonitor.setProgress(0);
        
        task = new Task();
        task.addPropertyChangeListener(this);
        task.execute();
        
 
		GregorianCalendar Now = new GregorianCalendar(); // aujourd'hui
		GregorianCalendar End = new GregorianCalendar(Now.get(Calendar.YEAR), Now.get(Calendar.MONTH), Now.get(Calendar.DAY_OF_MONTH));
		End.add(Calendar.DAY_OF_YEAR, 1);
		
		Integer nbAnnee = (Integer)jComboBox1.getSelectedItem();
        GregorianCalendar Start = new GregorianCalendar(End.get(Calendar.YEAR) - nbAnnee.intValue(), Calendar.JANUARY, 1);
		
			
		port infoport = (port)jComboBox2.getSelectedItem();
		Proceed computeDownload =  new Proceed(_DirPathToResult, Start, End, infoport.nom(), infoport.zone(), infoport.opt());
        computeDownload.run();
    }
	
	
	
	/**
	 * Le manager de tous les call back de notre UI
	 * @see java.util.EventObject
	 * @param event l'evenement recu
	 */
	public void mylisternerManager(java.util.EventObject event) 
	{
		Object oEventSendeer = event.getSource();
		
		//------------------------------------------------------
		// Issu de la progressbar
		//------------------------------------------------------
		if (oEventSendeer instanceof UIPhase1.Task)
		{
        	if ((event instanceof PropertyChangeEvent) && ("progress" == ((PropertyChangeEvent) event).getPropertyName()))
        	{
        		int progress = (Integer) ((PropertyChangeEvent) event).getNewValue();
        		 
                 progressMonitor.setProgress(progress);
                 String message = String.format("Completed %d%%.\n", progress);
                 progressMonitor.setNote(message);

                 if (progressMonitor.isCanceled() || task.isDone()) 
                 {
                     Toolkit.getDefaultToolkit().beep();
                     if (progressMonitor.isCanceled()) 
                     {
                         task.cancel(true);
                     } 
                     jButton2.setEnabled(true);
                 }        		
        	}
		}

		//------------------------------------------------------
		// Issu de la panellerie
		//------------------------------------------------------
		else if (oEventSendeer instanceof JComponent)
		{
			JComponent Jcompo = (JComponent)oEventSendeer;
			
			System.out.println("propertyChange evt :" + event);
			
			//-------------------------
			// la date
			//-------------------------
	        if (Jcompo instanceof com.toedter.calendar.JDateChooser)
	        {
	        	if ((event instanceof PropertyChangeEvent)) 
	        	{
	        		System.out.println(((PropertyChangeEvent)event).getPropertyName());
	        	}
	        } 
			else if (Jcompo.equals(jButton1))
			{
				System.out.println("Lancement du download");
				jButton1.setEnabled(false);
		        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		        //Instances of javax.swing.SwingWorker are not reusuable, so
		        //we create new instances as needed.
		        Task task = new Task();
		        task.addPropertyChangeListener(this);
		        task.execute();				
			}
			else if (Jcompo.equals(jButton2))
			{
				jFileChooser1 = new JFileChooser();
				jFileChooser1.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			    int returnVal = jFileChooser1.showOpenDialog(getParent());
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			    	jTextField1.setText(jFileChooser1.getSelectedFile().getName());
			       System.out.println("You chose to open this file: " +
			    		   jFileChooser1.getSelectedFile().getName());
			    }
			}

			System.out.println(Jcompo);
		}
		
	}


	@Override
	public void propertyChange(PropertyChangeEvent evt) 
	{
		mylisternerManager (evt);
	}


	@Override
	public void menuKeyPressed(MenuKeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void menuKeyReleased(MenuKeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void menuKeyTyped(MenuKeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void focusGained(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void focusLost(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}
