package dev.maree.phase1.model;

public class InfoPortTools 
{
	public enum port 
	{
	       // 		// Brest =   "port=BREST               &zone=11&opt=12&compute=TRUE&portsel=map&fuseau=0&dd=25&mm=3&yyyy=2012&jour=7&iaction=+++++++Calculer+++++++";
		// St Quay = "port=SAINT-QUAY-PORTRIEUX&zone=11&opt=12&compute=TRUE&portsel=map&fuseau=0&dd=16&mm=1&yyyy=2012&jour=7&iaction=+++++++Calculer+++++++

	    Brest ("BREST", "11", "12"),
	    StQuay ("SAINT-QUAY-PORTRIEUX", "11", "12");

	    private String _nom;   
	    private String _zone;
	    private String _opt; 
	    
	    port(String nom, String zone, String opt) 
	    {
	        _nom = nom;
	        _zone= zone;
	        _opt = opt;
	    }
	    
	    public String nom() { return _nom; }
	    public String zone() { return _zone; }
	    public String opt() { return _opt; }
	}
	
	
	public static String getPort(String infoport) 
	{
		// TODO Auto-generated method stub
		return null;
	}

	public static String getZone(String infoport) 
	{
		// TODO Auto-generated method stub
		return null;
	}

	public static String getOpt(String infoport) 
	{
		// TODO Auto-generated method stub
		return null;
	}

}
