package dev.maree.phase1.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.CookieHandler;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;


public class Proceed implements Runnable
{
	final String _ShomURL = "http://www.shom.fr/ann_marees/cgi-bin/predit_ext/choixp";
	public File _output = null;
	GregorianCalendar _Start = null;
	GregorianCalendar _End = null;
	String _port = null;
	String _zone = null;
	String _opt = null;
	
	public Proceed (File output, GregorianCalendar Start, GregorianCalendar End, String port, String zone, String opt)
	{
		_output = output;
		_Start = Start;
		_End = End;
		_port = port;
		_opt = opt;
		_zone = zone;
	}

	@Override
	public void run() 
	{
		try 
		{
			Go();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}	
	
	public void Go() throws Exception
	{
		//--------------------
		// le format des dates pour debug
		//--------------------
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy kk:mm:ss");
		SimpleDateFormat sdfforfile = new SimpleDateFormat("yyyy-MM-dd");

		//--------------------
		// le fichier de donnees
		//--------------------
		File outDir = _output; // new File ("e:\\tmp\\Shom_Brest_2009-1-1_2011-12-31.csv");
		String outName = "Shom_" + _port + "_" + sdfforfile.format(_Start.getTime()) + "_" + sdfforfile.format(_End.getTime()) + ".csv";
		File out = new File (outDir, outName);
		FileWriter fw = new FileWriter(out, false);
		fw.write("#-----------------------------------------------------------------------------------" + "\n");
		fw.write("# format:" + "\n");
		fw.write("# date;Julian Day;heure;hauteur;....;heure;hauteur;" + "\n");
		fw.write("# Il doit y avoir 24 paquets heure;hauteur de 0:00 a 23:00 " + "\n");
		fw.write("# " + "\n");
		fw.write("# Le calcul du julian day est lie a la formule (7.1) " + "\n");
		fw.write("#-----------------------------------------------------------------------------------" + "\n");



		


		//--------------------
		// Interval de date de l'export
		//--------------------
		GregorianCalendar Start = _Start; // new GregorianCalendar (2009, Calendar.JANUARY, 1, 0, 0, 0);
		GregorianCalendar End = _End; // new GregorianCalendar (2011, Calendar.DECEMBER, 31, 23, 59, 59);
		GregorianCalendar Cur = Start;
		System.out.println("From: " + sdf.format(Start.getTime()) + "       To: " + sdf.format(End.getTime()));

		
		//--------------------
		// Info du status
		//--------------------
		int nbBoucle = 0;
		double nbSemaine = ((double)(End.getTimeInMillis() - Start.getTimeInMillis()) / (1000.0 * 60.0 * 60.0 * 24.0 * 7.0));
		double pas = 100.0 / nbSemaine;
		

		//--------------------
		// Pour tous les jours de l'interval
		//--------------------
		boolean portMustBeLogged = true;
		while (Cur.before(End))
		{
			StatusManager.setStatus(0 + (int)((nbBoucle++) * pas));
			
			//--------------------
			// Recup des info pour une semaine
			//--------------------
			System.out.println("-- download des infos de la semaine du: " + sdf.format(Cur.getTime()));
			this.downloadInfoMareeDeLaSemaine (Cur, fw, portMustBeLogged);
			portMustBeLogged = false;
			Cur.add(Calendar.DATE, 7);
		}
		StatusManager.setStatus(101);
		fw.close();

	}
	
	
	public void downloadInfoMareeDeLaSemaine(GregorianCalendar jourCalcul, FileWriter fw, boolean tobeLogged) throws Exception 
	{
		//--------------------
		// Build des info reseau, l'URL
		//--------------------
		

		
		
		
		//--------------------
		// Build des info reseau, le contenu du post, utiliser fiddler pour les autres ports
		//
		// Brest =   "port=BREST               &zone=11&opt=12&compute=TRUE&portsel=map&fuseau=0&dd=25&mm=3&yyyy=2012&jour=7&iaction=+++++++Calculer+++++++";
		// St Quay = "port=SAINT-QUAY-PORTRIEUX&zone=11&opt=12&compute=TRUE&portsel=map&fuseau=0&dd=16&mm=1&yyyy=2012&jour=7&iaction=+++++++Calculer+++++++
		//--------------------
		String Get = BuildPostMessageinUTtime (_port, 1, _zone, _opt, 
				jourCalcul.get(Calendar.DAY_OF_MONTH),  (jourCalcul.get(Calendar.MONTH) + 1), jourCalcul.get(Calendar.YEAR),
				fw,	tobeLogged);
		
		
		//--------------------
		// Envoye de la requete
		//--------------------
		String reponseShom = "";		
		try 
		{
		    URL url = new URL(Get);
		    CookieHandler handler = CookieHandler.getDefault();
		     if (handler != null)    
		     {
		          Map<String, List<String>> headers= new HashMap<String, List<String>>();
		          List<String> values = new Vector<String>();
		          values.add("SHOM-port="+_port+"&"+_zone);
		          headers.put("Cookie", values);
		          handler.put(url.toURI(), headers); 
		     }
		     
		    URLConnection conn = url.openConnection();
		    conn.setDoOutput(true);
		    /*OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
		    wr.write(Post);
		    wr.flush();*/

		    // Get the response
		    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		    String line;
		    while ((line = rd.readLine()) != null) 
		    {
		    	reponseShom += line;
		    }
		  //  wr.close();
		    rd.close();
		} 
		catch (Exception e) {}
			
		//--------------------
		// Parse de la requete
		//--------------------
		String Info = parseSHOMResponse(reponseShom);



		//--------------------
		// passage de la string au tableau des valeur de hauteur d'eau heure par heure (de 0:00 a 23:00)
		//--------------------
		ArrayList<Float> valeur = new ArrayList<Float>();
		getValeurFromInfo (Info, valeur);
		if (valeur.size() != 7 * 24)
		{
			System.out.println(Info);
			throw new Exception("Invalide number echantillon : " + valeur.size());
		}
		
		//--------------------
		// Et on met ca dans le fichier !
		//--------------------
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String msg = "";
		GregorianCalendar pipo = (GregorianCalendar) jourCalcul.clone();
		for (int i = 0; i < 7; i++)
		{
			msg += (sdf.format (pipo.getTime()) + ";");
			double JD = 0.; // CalculAstroInterne.calculJDFromGregorian (pipo);
			msg += Double.toString(JD) + ";";
			for (int j = i*24; j < (i+1)*24; j++)
			{
				int heure = j-i*24;
				msg +=  Integer.toString(heure) + ";" + valeur.get(j) + ";";
					
			}
			fw.write(msg + "\n");
			msg = "";
			pipo.add(Calendar.DATE, 1);
		}

	}
	
	private  String parseSHOMResponse(String reponseShom) 
	{
		String tagStart = "<table";
		String tagEnd = "/table>";
		int indexStart = reponseShom.indexOf(tagStart);
		indexStart = reponseShom.indexOf(tagStart, indexStart + 1);
		indexStart = reponseShom.indexOf(tagStart, indexStart + 1);
		int indexFin = reponseShom.indexOf(tagEnd, indexStart) + tagEnd.length();
		String tablePertinente = reponseShom.substring(indexStart, indexFin);
		
		// suppression deux premieres lignes
		String Info = suppressionLigneTable (tablePertinente, 0, 3);
		Info = suppressionLigneTable (Info, 1, 1);// ok
		Info = suppressionLigneTable (Info, 2, 2);
		Info = suppressionLigneTable (Info, 3, 1);
		Info = suppressionLigneTable (Info, 4, 2);
		Info = suppressionLigneTable (Info, 5, 1);
		Info = suppressionLigneTable (Info, 6, 2);
		Info = suppressionLigneTable (Info, 7, 1);
		Info = suppressionLigneTable (Info, 8, 2);
		Info = suppressionLigneTable (Info, 9, 1);
		Info = suppressionLigneTable (Info, 10, 2);
		Info = suppressionLigneTable (Info, 11, 1);
		Info = suppressionLigneTable (Info, 12, 2);
		Info = suppressionLigneTable (Info, 13, 1);

		return Info;
	}




	private  void getValeurFromInfo(String info, ArrayList<Float> valeur) throws Exception 
	{
		String tagStart = "<th>";
		String tagFin = "</td>";
		int indexPrev = 0;
		int indexStart = 0;
		int indexFin = 0;
		
		indexStart = info.indexOf(tagStart, indexStart) + tagStart.length();
		while (indexStart > 0)
		{
			indexFin = info.indexOf(tagFin, indexStart);
			String kiki = info.substring(indexStart, indexFin);
			kiki = kiki.replace("m", "");
			try
			{
				valeur.add(Float.parseFloat(kiki));
			}
			catch (Exception e)
			{
				System.out.println(indexStart + " --- " + indexFin);
				System.out.println(info);
				System.out.println(e.getMessage());
				throw e;
			}
			indexPrev = indexStart;
			indexStart = info.indexOf(tagStart, indexStart) + tagStart.length();
			if (indexStart < indexPrev)
				indexStart = -1;				
		}
		return;
		
	}

	private  String suppressionLigneTable(String reponseShom, int nblignealaisser, int nbligneadetruire) 
	{
		String retour = reponseShom;
		String tagStart = "<tr";
		String tagEnd = "/tr>";
		int indexStart = 0;
		int indexFin = 0;
		int indexFin2 = 0;
		boolean forceexit = false;
		
		for (int i = 0; i < nblignealaisser; i++)
		{
			indexStart = retour.indexOf(tagStart, indexStart + 1);
			if (indexStart < 0)
			{
				forceexit = true;
				break;
			}
		}

		indexStart++;
		for (int i = 0; !forceexit && (i < nbligneadetruire); i++)
		{
			indexStart = retour.indexOf(tagStart, indexStart);
			if (indexStart < 0)
			{
				forceexit = true;
				break;
			}
			indexFin = retour.indexOf(tagEnd, indexStart+1) + tagEnd.length();
			indexFin2 = retour.indexOf(tagStart, indexStart+1);
			if ((indexFin2 < indexFin) && (indexFin2 > 0)) // cas du /tr> manquant ...
				indexFin = indexFin2;
			
			if (indexFin < 0)
			{
				forceexit = true;
				break;
			}
			String kiki = retour.substring(0, indexStart);
			kiki += retour.substring(indexFin);
			retour = kiki;
		}
		return retour;
	}

	private  String BuildPostMessageinUTtime (String ville, int fuseau, String zone, String opt, int day, int month, int year, FileWriter fw, boolean tobeLogged) throws IOException 
	{
		// http://www.shom.fr/maree/predictions/cgi-bin/predit_ext/choixp?opt=12&zone=27&port=BREST&date=28%206%202012&dd=28&mm=6&yyyy=2012&compute=TRUE&fuseau=2
		String retour = "http://www.shom.fr/maree/predictions/cgi-bin/predit_ext/choixp?";
		retour += "opt=" + opt;
		retour += "&zone=" + zone;
		retour += "&port=" + ville;
		retour += "&date="+day+"%20"+month+"%20"+year;
		retour += "&dd=" + day;
		retour += "&mm=" + month;
		retour += "&yyyy=" + year;
		retour += "&compute=TRUE";
		retour += "&portsel=map";
		retour += "&fuseau=" + Integer.toString (fuseau); // ex: fuseau =1 ==> heure UTC+1 horaire d'hiver
		if (tobeLogged)
		{
			fw.write("#-----------------------------------------------------------------------------------" + "\n");
			fw.write("# port :" + ville + "\n");
			fw.write("# Fuseau : UT+" + fuseau + "\n");
			fw.write("#-----------------------------------------------------------------------------------" + "\n");
		}
		
		return retour;
	}
}
