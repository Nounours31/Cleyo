package dev.maree.phase1.model;

public class StatusManager 
{
	private static StatusManager _instance = null;
	private int	_status = -1;
	
	private StatusManager()
	{}

	private static StatusManager getInstance()
	{
		if (_instance == null)
			_instance = new StatusManager();
		return _instance;
	}
	
	
	
	public static synchronized void setStatus (int i)
	{
		StatusManager x = StatusManager.getInstance();
		
		if (i < 0) i = 0;
		if (i > 100) i = 100;
		
		x._status = i;
		return;
	}
	
	public static synchronized int getStatus ()
	{
		StatusManager x = StatusManager.getInstance();
		return x._status;
	}
	
}
