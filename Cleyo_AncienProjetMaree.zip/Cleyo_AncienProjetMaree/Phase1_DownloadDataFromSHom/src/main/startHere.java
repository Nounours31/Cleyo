package main;

import javax.swing.UIManager;

import org.apache.log4j.Logger;
import dev.maree.phase1.ui.UIPhase1;

/**
 * @author pfs
 * @version 1.0
 */
public class startHere 
{
	static Logger _log = null;
	
	/**
	 * lancement de la phase 1 download des donnees
	 * @param args pas d'util
	*/
	public static void main(String[] args)  
	{
		//--------------------
		// le logger
		//--------------------
		_log = Logger.getLogger("vp.maree.phase1.logger");
		
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			UIPhase1 UI = new UIPhase1();
			UI.show(true);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
