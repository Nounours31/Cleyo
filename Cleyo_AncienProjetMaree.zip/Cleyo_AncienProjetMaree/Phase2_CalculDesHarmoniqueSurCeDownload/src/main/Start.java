package main;

import java.io.File;
import java.util.Calendar;
import java.util.TimeZone;

import dev.maree.harmonique.model.calculHarmonicFromSHOMData;
import dev.maree.prereq.constantes.Constantes;
import dev.maree.prereq.error.MyError;
import dev.maree.prereq.structuredonnee.ListStation;

public class Start {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		TimeZone utc = TimeZone.getTimeZone("UTC");
        TimeZone.setDefault(utc);

		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(utc);
		
        Constantes._sdf.setTimeZone(utc);
        Constantes._sdf4file.setTimeZone(utc);
		
		
		try 
		{
			//-----------------------------------------------------------------------
			// L'output
			//-----------------------------------------------------------------------
			File outDir = new File (Constantes.RepCoef);
			if (!outDir.exists())			
				outDir.mkdirs();

			//------------------------------------------------------------------------------------------------
			//-- le fichier de donnees du SHOM via Refmar validee
			//------------------------------------------------------------------------------------------------
			File inDir = new File (Constantes.RepDonneeCheck);
			if (!inDir.exists())
				return ;


			//------------------------------------------------------------------------------------------------
			//-- Choix user d'un fichier IN
			//------------------------------------------------------------------------------------------------
			String[] dowloadfiles = inDir.list();
			short NbDownloadedFiles = 0;
			for (String i : dowloadfiles)
				System.out.println("Indice: " + NbDownloadedFiles++ + " Nom: " + i);

			int choix = -1;
			boolean test = false;
			do
			{
				System.out.print("Votre choix ? ");

				int car = 0;
				String inputString = "";

				try
				{
					do
					{
						car = System.in.read();
						test = ((car > -1) && (car != 10) && (car != 13) );  // 10 = \n   13 = \r
						if (test)
							inputString += String.valueOf(Character.toChars(car));
					} while (test);
				}
				catch (Exception e)
				{
					System.out.println("Choix invalide");
					choix = -2;
				}


				if (choix != -2)
				{
					try
					{
						choix = Integer.parseInt(inputString);
					}
					catch (Exception e)
					{
						System.out.println("Choix n'est pas un integer");
					}
				}
				
				test = (choix > -1) && (choix < NbDownloadedFiles);
				if (!test)
					System.out.println("Choix trop petit ou superieur au nb fichier, a refaire");
			}
			while (!test);

			
			
			//------------------------------------------------------------------------------------------------
			//-- Choix du nom de la station
			//------------------------------------------------------------------------------------------------
			NbDownloadedFiles = 0;
			for (ListStation i : ListStation.values())
				System.out.println("Indice: " + NbDownloadedFiles++ + " Nom: " + i);

			int choixStation = -1;
			test = false;
			do
			{
				System.out.print("Votre choix ? ");

				int car = 0;
				String inputString = "";

				try
				{
					do
					{
						car = System.in.read();
						test = ((car > -1) && (car != 10) && (car != 13) );  // 10 = \n   13 = \r
						if (test)
							inputString += String.valueOf(Character.toChars(car));
					} while (test);
				}
				catch (Exception e)
				{
					System.out.println("Choix invalide");
					choixStation = -2;
				}


				if (choixStation != -2)
				{
					try
					{
						choixStation = Integer.parseInt(inputString);
					}
					catch (Exception e)
					{
						System.out.println("Choix n'est pas un integer");
					}
				}
				
				test = (choixStation > -1) && (choixStation < NbDownloadedFiles);
				if (!test)
					System.out.println("Choix trop petit ou superieur au nb fichier, a refaire");
			}
			while (!test);
			ListStation StationChoisie = ListStation.values()[choixStation];
			
			//------------------------------------------------------------------------------------------------
			//-- choix des fichier et creation si necessaire
			//------------------------------------------------------------------------------------------------
			File infile = new File (inDir, dowloadfiles[choix]);
			File outfile = new File (outDir, StationChoisie._nom + ".td4");
			
			if (outfile.exists())
				outfile.delete();
			
			
			
			
			//------------------------------------------------------------------------------------------------
			//-- calcul proprement dit
			//------------------------------------------------------------------------------------------------
			calculHarmonicFromSHOMData c = new calculHarmonicFromSHOMData (infile, outfile, StationChoisie);
			c.eval();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
