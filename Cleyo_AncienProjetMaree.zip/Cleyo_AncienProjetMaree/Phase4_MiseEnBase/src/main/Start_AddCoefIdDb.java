package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import dev.maree.harmonique.model.PublicApi;
import dev.maree.prereq.constantes.Constantes;
import dev.maree.sql.model.table_maree_coeff;
import dev.maree.sql.model.table_maree_uncoeff;

public class Start_AddCoefIdDb {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		TimeZone utc = TimeZone.getTimeZone("UTC");
        TimeZone.setDefault(utc);

		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(utc);
		
        Constantes._sdf.setTimeZone(utc);
        Constantes._sdf4file.setTimeZone(utc);
		
		
		try 
		{
			//------------------------------------------------------------------------------------------------
			//-- le fichier de donnees du SHOM via Refmar validee
			//------------------------------------------------------------------------------------------------
			File inDir = new File (Constantes.RepCoef);
			if (!inDir.exists())
				return ;
			
			File[] files = inDir.listFiles();
			
			
			
			for (File unFile : files)
			{
				File infile = new File (inDir, unFile.getName());
				InputStream is = new FileInputStream (infile);
				BufferedReader in = new BufferedReader(new InputStreamReader (is));
				String Lue = null;
				
				table_maree_coeff tmc = new table_maree_coeff();
				table_maree_uncoeff tmuc = new table_maree_uncoeff();

				tmc.set_port(unFile.getName().replace(".td4", ""));
				int tmcid = 0;
				
				while ((Lue = in.readLine()) != null)
				{
					if (Lue.startsWith("\""))
						continue;

					Lue = Lue.replace ("\t", " ");
					String LueClean = Lue.replace("  ", " ");
					while (LueClean.length() != Lue.length())
					{
						Lue = LueClean;
						LueClean = Lue.replace("  ", " ");
					}
					String[] infos = Lue.split(" ");

					
					if (Lue.startsWith("METRIC"))
					{
						if (infos.length != 5)
							break;
						
						tmc.set_Metric1(Integer.parseInt(infos[1]));
						tmc.set_Metric2(Integer.parseInt(infos[2]));
						tmc.set_Metric3(Integer.parseInt(infos[3]));
						tmc.set_Metric4(Integer.parseInt(infos[4]));
					}

					else if (Lue.startsWith("Z0"))
					{
						if (infos.length != 2)
							break;
						
						tmc.set_Z0(Double.parseDouble(infos[1]));
						tmcid = tmc.AddInCoef();
					}

					else
					{
						tmuc.set_nom(infos[0]);
						tmuc.set_amplitude(Double.parseDouble(infos[1]));
						tmuc.set_phase(Double.parseDouble(infos[2]));
						tmuc.set_uid_tablecoef(tmcid);
						tmuc.AddInUnCoef();
					}
				}
				in.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void kiki (String[] args) 
	{
		TimeZone utc = TimeZone.getTimeZone("UTC");
        TimeZone.setDefault(utc);

		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(utc);
		
        Constantes._sdf.setTimeZone(utc);
        Constantes._sdf4file.setTimeZone(utc);
		
		
		try 
		{
			//------------------------------------------------------------------------------------------------
			//-- le fichier de donnees du SHOM via Refmar validee
			//------------------------------------------------------------------------------------------------
			File inDir = new File (Constantes.RepCoef);
			if (!inDir.exists())
				return ;


			//------------------------------------------------------------------------------------------------
			//-- Choix user d'un fichier IN
			//------------------------------------------------------------------------------------------------
			String[] dowloadfiles = inDir.list();
			short NbDownloadedFiles = 0;
			for (String i : dowloadfiles)
				System.out.println("Indice: " + NbDownloadedFiles++ + " Nom: " + i);

			int choix = -1;
			boolean test = false;
			do
			{
				System.out.print("Votre choix ? ");

				int car = 0;
				String inputString = "";

				try
				{
					do
					{
						car = System.in.read();
						test = ((car > -1) && (car != 10) && (car != 13) );  // 10 = \n   13 = \r
						if (test)
							inputString += String.valueOf(Character.toChars(car));
					} while (test);
				}
				catch (Exception e)
				{
					System.out.println("Choix invalide");
					choix = -2;
				}


				if (choix != -2)
				{
					try
					{
						choix = Integer.parseInt(inputString);
					}
					catch (Exception e)
					{
						System.out.println("Choix n'est pas un integer");
					}
				}
				
				test = (choix > -1) && (choix < NbDownloadedFiles);
				if (!test)
					System.out.println("Choix trop petit ou superieur au nb fichier, a refaire");
			}
			while (!test);

			
			
			
			//------------------------------------------------------------------------------------------------
			//-- choix des fichier et creation si necessaire
			//------------------------------------------------------------------------------------------------
			File infile = new File (inDir, dowloadfiles[choix]);
			
			
			
			
			
			//------------------------------------------------------------------------------------------------
			//-- calcul proprement dit
			//------------------------------------------------------------------------------------------------
			GregorianCalendar gc = new GregorianCalendar(2013, Calendar.JUNE, 22);
			PublicApi pa = new  PublicApi(gc, infile.getAbsolutePath());
			
			
			List<Double> infomaree = pa.MarreGrammeduJour();
			for (int i = 0; i < infomaree.size(); i++)
			{
				System.out.println("Amplitude [heure" + i + "] = " + infomaree.get(i));
			}
			
			List<Double> horaireEtale = pa.getHoraireEtale();
			List<Double> hauteurEtale = pa.getHauteurEau(horaireEtale);
			for (int i = 0; i < horaireEtale.size(); i++)
			{
				System.out.println("Etale  " + pa.CouvHeureInDoubleToHeureTXT(horaireEtale.get(i)) + " Amplitude = " +  hauteurEtale.get(i));
			}

			List<Double> PM = new ArrayList<Double>(); 
			List<Double> BM = new ArrayList<Double>(); 
			pa.InfoMareeJour(PM, BM);
			int j = 0;
			for (int i = 0; i < PM.size();)
			{
				System.out.println("PM  horaire" + pa.CouvHeureInDoubleToHeureTXT(PM.get(i++)) + " Amplitude = " + PM.get(i++) + " Coef = undef");
			}
			for (int i = 0; i < BM.size();)
			{
				System.out.println("BM  horaire" + pa.CouvHeureInDoubleToHeureTXT(BM.get(i++)) + " Amplitude = " + BM.get(i++) );
			}
			
			System.out.println("PM1" + pa.CouvHeureInDoubleToHeureTXT(PM.get(0)));
			pa.getCoefMaree(PM.get(0), BM.get(0));
			System.out.println("PM2" + pa.CouvHeureInDoubleToHeureTXT(PM.get(2)));
			pa.getCoefMaree(PM.get(2), BM.get(2));

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
