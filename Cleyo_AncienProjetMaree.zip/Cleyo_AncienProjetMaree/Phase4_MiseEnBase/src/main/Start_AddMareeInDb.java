package main;

import java.io.File;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import dev.maree.harmonique.model.PublicApi;
import dev.maree.prereq.constantes.Constantes;
import dev.maree.prereq.structuredonnee.DateHauteurSQLForMareeCalcul;
import dev.maree.sql.model.table_maree_horaireMaree;
import dev.maree.sql.model.table_maree_unhoraireMaree;

public class Start_AddMareeInDb 
{
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		TimeZone utc = TimeZone.getTimeZone("UTC");
		TimeZone.setDefault(utc);

		Calendar cal = Calendar.getInstance();
		cal.setTimeZone(utc);

		Constantes._sdf.setTimeZone(utc);
		Constantes._sdf4file.setTimeZone(utc);


		try 
		{
			//------------------------------------------------------------------------------------------------
			//-- le fichier de donnees du SHOM via Refmar validee
			//------------------------------------------------------------------------------------------------
			File inDir = new File (Constantes.RepCoef);
			if (!inDir.exists())
				return ;
			
			File[] files = inDir.listFiles();

			table_maree_horaireMaree tmhm_init = new table_maree_horaireMaree();
			tmhm_init.AddTable();
			table_maree_unhoraireMaree tmuhm_init = new table_maree_unhoraireMaree();
			tmuhm_init.AddTable();
			
			for (File unFile : files)
			{
				File infile = new File (inDir, unFile.getName());
				
				table_maree_horaireMaree tmhm = new table_maree_horaireMaree();
				if (unFile.getName().equals("Brest.td4"))
					tmhm.set_port(1);
				else if (unFile.getName().equals("StMalo.td4"))
					continue;
				else 
				{
					System.out.println("ca chie: " + unFile.getName());
					break;
				}
				int tmhmid = 0;


				//------------------------------------------------------------------------------------------------
				//-- calcul proprement dit
				//------------------------------------------------------------------------------------------------
				GregorianCalendar gcStart = new GregorianCalendar(2013, Calendar.JUNE, 1);
				GregorianCalendar gcFin = new GregorianCalendar(2048, Calendar.JANUARY, 10);
				
				GregorianCalendar gc = gcStart;
				gc.add(Calendar.DAY_OF_MONTH, -1);

				List<Double> 					PM 			= new ArrayList<Double>(); 
				List<Double> 					BM 			= new ArrayList<Double>(); 
				PublicApi 						pa 			= new  PublicApi(gc, infile.getAbsolutePath());
				pa.InfoMareeJour(PM, BM);
				DateHauteurSQLForMareeCalcul.add (PM, BM, gc);
				
				gc.add(Calendar.DAY_OF_MONTH, 1);
				while (gc.before(gcFin))
				{
					tmhm.set_jour(new Date(gc.getTimeInMillis()));
					tmhmid = tmhm.AddInCoef();

					pa = new  PublicApi(gc, infile.getAbsolutePath());
					PM = new ArrayList<Double>(); 
					BM = new ArrayList<Double>(); 

					pa.InfoMareeJour(PM, BM);
					DateHauteurSQLForMareeCalcul.add (PM, BM, gc);
					
					
					for (int i = 0; i < DateHauteurSQLForMareeCalcul.nbInfoMaree(gc); i++)
					{
						table_maree_unhoraireMaree tmuhm = new table_maree_unhoraireMaree();
						tmuhm.set_heure(DateHauteurSQLForMareeCalcul.getHeure(i, gc));
						tmuhm.set_hauteur(DateHauteurSQLForMareeCalcul.getHauteur(i, gc));
						if (tmhm.get_port() != 1) // Les coef sont calculer a Brest ...
							tmuhm.set_coef(-1);
						else
							tmuhm.set_coef(DateHauteurSQLForMareeCalcul.getCoef(i, gc));
						tmuhm.set_type(DateHauteurSQLForMareeCalcul.getType(i, gc));
						tmuhm.set_uid_tablehoraireMaree(tmhmid);
						tmuhm.AddInCoef();
					}

					gc.add(Calendar.DAY_OF_MONTH, 1);
					System.out.println(Constantes._sdf.format(gc.getTime()));
				} 
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}