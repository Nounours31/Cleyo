package dev.maree.prereq.error;

public class MyError 
{
	private int _id;
	private String _Info;
	
	public MyError (int id) { _id = id;}
	public MyError (int id, String info) { _id = id; _Info = info;}
	
	
	static public MyError sOK = new MyError (0);

}
