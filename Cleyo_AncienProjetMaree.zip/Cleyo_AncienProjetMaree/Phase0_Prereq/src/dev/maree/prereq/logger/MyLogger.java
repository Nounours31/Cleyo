package dev.maree.prereq.logger;

import java.util.ArrayList;
import java.util.Enumeration;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import dev.maree.prereq.constantes.Constantes;


public class MyLogger
{	
	public static Logger getLogger ()
	{
		Logger log = Logger.getLogger(Constantes.NomLogger);
		return log;
	}
	



}