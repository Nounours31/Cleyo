package dev.maree.prereq.exception;

public class MareeException extends Exception {

	public MareeException() {
		// TODO Auto-generated constructor stub
	}

	public MareeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MareeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MareeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
