package dev.maree.prereq.structuredonnee;

public class MareeEnum {

}



