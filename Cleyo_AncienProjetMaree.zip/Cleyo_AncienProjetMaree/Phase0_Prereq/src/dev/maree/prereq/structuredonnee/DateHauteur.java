package dev.maree.prereq.structuredonnee;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import dev.maree.prereq.constantes.Constantes;

public class DateHauteur 
{

	private GregorianCalendar 			_horaireMaree;
	private double						_hauteurEau;
	private static 	GregorianCalendar 	_origineMonde = init();
	private static 	double 				_zerooriginel = -10.0;
	
	@Override
	public String toString() 
	{
		return "DateHauteur [_horaireMaree=" + Constantes._sdf.format(_horaireMaree.getTime()) + ", _hauteurEau=" + _hauteurEau + "]";
	}

	private static GregorianCalendar init() 
	{
		GregorianCalendar x = new GregorianCalendar(TimeZone.getTimeZone("UTC"), Locale.ROOT);
		x.set(1970, Calendar.JANUARY, 1, 0, 0, 1);
		return x;
	}

	public DateHauteur(GregorianCalendar _horaireMaree, double _hauteurEau) 
	{
		super();
		this._horaireMaree = _horaireMaree;
		this._hauteurEau = _hauteurEau;
	}

	public DateHauteur() 
	{
		super();
		this._horaireMaree = init();		
		this._horaireMaree.add(Calendar.SECOND, -1); // juste avant le debut du monde ...
		this._hauteurEau = _zerooriginel - 1.0;
	}

	public GregorianCalendar get_horaireMaree() {
		return _horaireMaree;
	}

	public void set_horaireMaree(GregorianCalendar _horaireMaree) {
		this._horaireMaree = _horaireMaree;
	}


	public double get_hauteurEau() {
		return _hauteurEau;
	}

	public void set_hauteurEau(double _hauteurEau) {
		this._hauteurEau = _hauteurEau;
	}
	
	public boolean isValid()
	{
		if ((this._horaireMaree.before(_origineMonde)) || (this._hauteurEau < _zerooriginel))
			return false;
		return true;
	}
	
	static public long interval (DateHauteur x, DateHauteur y) // en milliseconde
	{
		return x.get_horaireMaree().getTimeInMillis() - y.get_horaireMaree().getTimeInMillis();
	}

	static public double  MilliSecond2Hour (long x) // en milliseconde
	{
		return  ((double)x) / (1000.0 * 60 * 60);
	}
}
