package dev.maree.prereq.structuredonnee;

public enum ListStation {
	Brest ("Brest", 103),
	SaintMalo ("StMalo", 55),
	Roscoff ("Roscoff", 60);

	private ListStation (String nom, int id)
	{
		_nom = nom;
		_id = id;
	}

	public int _id;
	public String _nom;
}
