package dev.maree.prereq.structuredonnee;

public enum ListDataType {
	BrutTempsReel ("Brut", 1),
	Brut10minutes ("Brut10mn", 2),
	Differee10minutes ("Diferee10Min", 3),
	DiffereeHoraire ("DifereeHoraire", 4);

	private ListDataType (String nom, int id)
	{
		_nom = nom;
		_id = id;
	}

	public int _id;
	public String _nom;
}
