package dev.maree.prereq.constantes;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class Constantes {
	
	public static String NomLogger = " dev.maree.code";
	
	public static String RepDonnee = "E:\\WS\\svn\\maree\\data";
	public static String RepDonneeDownload = "E:\\WS\\svn\\maree\\data\\download";
	public static String RepDonneeDownloadCorrigee = "E:\\WS\\svn\\maree\\data\\downloadCorrigee";
	public static String RepDonneeCheck = "E:\\WS\\svn\\maree\\data\\Check";
	public static String RepCoef = "E:\\WS\\svn\\maree\\data\\Coef";
	
	public static SimpleDateFormat _sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE);
	public static SimpleDateFormat _sdf4file = new SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE);

}
