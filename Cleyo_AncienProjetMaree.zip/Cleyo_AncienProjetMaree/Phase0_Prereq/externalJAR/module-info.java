/**
 * 
 */
/**
 * @author PFS
 *
 */
module projetmaree {
	exports Jama.examples;
	exports dev.maree.prereq.structuredonnee;
	exports Jama.util;
	exports dev.maree.prereq.logger;
	exports com.toedter.components;
	exports dev.maree.sql.model;
	exports dev.maree.prereq.exception;
	exports Jama;
	exports start;
	exports main;
	exports dev.maree.prereq.error;
	exports dev.maree.datafromrefmar.model;
	exports com.toedter.calendar;
	exports Jama.test;
	exports com.toedter.calendar.demo;
	exports com.toedter.plaf;
	exports dev.maree.prereq.constantes;
	exports dev.maree.harmonique.model;
	exports dev.maree.phase1.ui;
	exports dev.maree.miseenformefromrefmar.model;
	exports dev.maree.phase1.model;

	requires rt;
}